/**
 * Created by Administrator on 2016/12/14.
 */
$(function () {
    $(".title1 li").hover(function () {
        var lineLeft = ["7px", "128px"]
        $(this).addClass("current").siblings().removeClass("current");
        $(".tab-1 .line").stop().animate({"left": lineLeft[$(this).index()]}, 800);
        $(".ul-box1 ul.clearfix").stop().animate({"left":-$(this).index()*$(".ul-box1 ul li").width()},800);
    });
    $(".lunbo-squera li").hover(function () {
        $(this).addClass("current").siblings().removeClass("current");
        $(".lunbo-main").stop().animate({"left":-$(this).index()*298},800)
    });
})